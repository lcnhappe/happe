isequal(2,CStrAinBP({'a','b'},{'b','c'}))
