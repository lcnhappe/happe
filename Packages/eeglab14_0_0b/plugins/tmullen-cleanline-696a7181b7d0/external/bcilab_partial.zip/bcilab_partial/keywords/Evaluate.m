function res = Evaluate(varargin)
% alternative form for exp_eval()
res = exp_eval(varargin{:});