function res = Hold(varargin)
% shortcut form for exp_hold()
res = exp_hold(varargin{:});