function res = Pattern(varargin)
% shortcut form for exp_pattern()
res = exp_pattern(varargin{:});