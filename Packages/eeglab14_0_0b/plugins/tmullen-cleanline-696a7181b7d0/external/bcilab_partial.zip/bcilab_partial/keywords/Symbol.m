function res = Symbol(varargin)
% shortcut form for exp_symbol()
res = exp_symbol(varargin{:});